package com.example.demo.converter;

import com.example.demo.constants.IndexConstants;
import com.example.demo.domain.model.StringPosition;
import com.example.demo.exceptions.StringConversionException;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Component;

import org.springframework.stereotype.Component;

@Component
public class StringToStringPositionConverter {
    public StringPosition[] convert(String input) {
        try {
            // Si la entrada es nula, la inicializamos con una cadena vacía
            if (input == null) {
                input = "";
            }

            StringPosition[] result = new StringPosition[IndexConstants.INDICES.length];
            for (int i = 0; i < IndexConstants.INDICES.length; i++) {
                int start = IndexConstants.INDICES[i][0];
                int end = IndexConstants.INDICES[i][1];

                // Aseguramos que el índice final no sobrepase la longitud de la entrada
                end = Math.min(end, input.length());

                // Extraemos la subcadena y la rellenamos con espacios en blanco si es necesario
                String substr = input.substring(start, end);
                if (end - start > 0) {
                    substr = String.format("%-" + (end - start) + "s", substr);
                }

                result[i] = new StringPosition(substr, i);
            }

            return result;

        } catch (ArrayIndexOutOfBoundsException e) {
            throw new IndexOutOfBoundsException("Error en los índices al convertir la cadena: " + e.getMessage());
        } catch (Exception e) {
            throw new StringConversionException("Se produjo un error inesperado al convertir la cadena: " + e.getMessage(), e);
        }
    }
}

