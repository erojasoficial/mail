package com.example.demo.domain.entity;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(schema = "EMAIL_LISTENER", name = "EVENTOS_EMAIL")
public class EventosEmail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer EVENTO_ID;

    private String EVENTO_TIPO;
    private String EVENTO_ESTADO = "ENCOLADO";
    private String PROCESAMIENTO_ESTADO = "NO PROCESADO";
    private Date EVENTO_FECHA = new Date();
    private Date PROCESAMIENTO_FECHA;

    @Column(length = 100000)
    private String EVENTO_DETALLE;
    private String DATA_QUEUE_ENTRADA;
    private String DATA_QUEUE_SALIDA;
    private String EMAIL_DESTINO;
    private String EMAIL_ASUNTO;

    @Column(length = 100000)
    private String EMAIL_MENSAJE;

    public Integer getEVENTO_ID() {
        return EVENTO_ID;
    }

    public void setEVENTO_ID(Integer EVENTO_ID) {
        this.EVENTO_ID = EVENTO_ID;
    }

    public String getEVENTO_TIPO() {
        return EVENTO_TIPO;
    }

    public void setEVENTO_TIPO(String EVENTO_TIPO) {
        this.EVENTO_TIPO = EVENTO_TIPO;
    }

    public String getEVENTO_ESTADO() {
        return EVENTO_ESTADO;
    }

    public void setEVENTO_ESTADO(String EVENTO_ESTADO) {
        this.EVENTO_ESTADO = EVENTO_ESTADO;
    }

    public String getPROCESAMIENTO_ESTADO() {
        return PROCESAMIENTO_ESTADO;
    }

    public void setPROCESAMIENTO_ESTADO(String PROCESAMIENTO_ESTADO) {
        this.PROCESAMIENTO_ESTADO = PROCESAMIENTO_ESTADO;
    }

    public Date getEVENTO_FECHA() {
        return EVENTO_FECHA;
    }

    public void setEVENTO_FECHA(Date EVENTO_FECHA) {
        this.EVENTO_FECHA = EVENTO_FECHA;
    }

    public Date getPROCESAMIENTO_FECHA() {
        return PROCESAMIENTO_FECHA;
    }

    public void setPROCESAMIENTO_FECHA(Date PROCESAMIENTO_FECHA) {
        this.PROCESAMIENTO_FECHA = PROCESAMIENTO_FECHA;
    }

    public String getEVENTO_DETALLE() {
        return EVENTO_DETALLE;
    }

    public void setEVENTO_DETALLE(String EVENTO_DETALLE) {
        this.EVENTO_DETALLE = EVENTO_DETALLE;
    }

    public String getDATA_QUEUE_ENTRADA() {
        return DATA_QUEUE_ENTRADA;
    }

    public void setDATA_QUEUE_ENTRADA(String DATA_QUEUE_ENTRADA) {
        this.DATA_QUEUE_ENTRADA = DATA_QUEUE_ENTRADA;
    }

    public String getDATA_QUEUE_SALIDA() {
        return DATA_QUEUE_SALIDA;
    }

    public void setDATA_QUEUE_SALIDA(String DATA_QUEUE_SALIDA) {
        this.DATA_QUEUE_SALIDA = DATA_QUEUE_SALIDA;
    }

    public String getEMAIL_DESTINO() {
        return EMAIL_DESTINO;
    }

    public void setEMAIL_DESTINO(String EMAIL_DESTINO) {
        this.EMAIL_DESTINO = EMAIL_DESTINO;
    }

    public String getEMAIL_ASUNTO() {
        return EMAIL_ASUNTO;
    }

    public void setEMAIL_ASUNTO(String EMAIL_ASUNTO) {
        this.EMAIL_ASUNTO = EMAIL_ASUNTO;
    }

    public String getEMAIL_MENSAJE() {
        return EMAIL_MENSAJE;
    }

    public void setEMAIL_MENSAJE(String EMAIL_MENSAJE) {
        this.EMAIL_MENSAJE = EMAIL_MENSAJE;
    }
}
