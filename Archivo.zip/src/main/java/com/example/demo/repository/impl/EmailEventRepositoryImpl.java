package com.example.demo.repository.impl;

import com.example.demo.domain.entity.EventosEmail;
import com.example.demo.repository.EventosEmailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public class EmailEventRepositoryImpl {

    @Autowired
    private EventosEmailRepository eventosEmailRepository;

    public int insertEmailEvent(String eventoTipo, String dataQueueEntrada, String dataQueueSalida,
                                String emailDestino, String emailAsunto, String emailMensaje) {

        EventosEmail eventosEmail = new EventosEmail();
        eventosEmail.setEVENTO_TIPO(eventoTipo);
        eventosEmail.setDATA_QUEUE_ENTRADA(dataQueueEntrada);
        eventosEmail.setDATA_QUEUE_SALIDA(dataQueueSalida);
        eventosEmail.setEMAIL_DESTINO(emailDestino);
        eventosEmail.setEMAIL_ASUNTO(emailAsunto);
        eventosEmail.setEMAIL_MENSAJE(emailMensaje);

        EventosEmail saved = eventosEmailRepository.save(eventosEmail);

        return saved.getEVENTO_ID();
    }

    public void updateEmailEventProcessingState(int eventId, String processingState) {
        EventosEmail eventosEmail = eventosEmailRepository.findById(eventId).orElse(null);
        if (eventosEmail != null) {
            eventosEmail.setPROCESAMIENTO_ESTADO(processingState);
            eventosEmail.setPROCESAMIENTO_FECHA(new Date());
            eventosEmailRepository.save(eventosEmail);
        }
    }

    public void updateEmailEventState(int eventId, String eventState) {
        EventosEmail eventosEmail = eventosEmailRepository.findById(eventId).orElse(null);
        if (eventosEmail != null) {
            eventosEmail.setEVENTO_ESTADO(eventState);
            eventosEmailRepository.save(eventosEmail);
        }
    }

}
