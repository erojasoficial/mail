package com.example.demo.business.impl;

import com.example.demo.business.ApiPostAndEmailEventUpdateStep;
import com.example.demo.domain.dto.SendMailRequest;
import com.example.demo.exceptions.ApiCallRuntimeException;
import com.example.demo.exceptions.JsonProcessingRuntimeException;
import com.example.demo.repository.impl.EmailEventRepositoryImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.ResourceAccessException;

@Component
public class ApiPostAndEmailEventUpdateStepImpl implements ApiPostAndEmailEventUpdateStep {
    private final ObjectMapper objectMapper;
    private final ApiServiceImpl apiService;
    private final EmailEventRepositoryImpl emailEventRepository;

    @Autowired
    public ApiPostAndEmailEventUpdateStepImpl(ObjectMapper objectMapper, ApiServiceImpl apiService, EmailEventRepositoryImpl emailEventRepository) {
        this.objectMapper = objectMapper;
        this.apiService = apiService;
        this.emailEventRepository = emailEventRepository;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        // Recuperamos el mensaje del ExecutionContext

        String message = (String) chunkContext.getStepContext().getStepExecution()
                .getJobExecution().getExecutionContext().get("message");
        Integer insertedId = (Integer) chunkContext.getStepContext().getStepExecution()
                .getJobExecution().getExecutionContext().get("insertedId");
        SendMailRequest customDto = (SendMailRequest) chunkContext.getStepContext().getStepExecution()
                .getJobExecution().getExecutionContext().get("customDto");

        System.out.println("mensaje2:"+message);
        System.out.println("InsertedId en Step2Tasklet: "+insertedId);
        System.out.println("InsertedId en Step2Tasklet: "+insertedId);
        try {
            String customDtoJson = objectMapper.writeValueAsString(customDto);
            System.out.println("customDto en Step2Tasklet: " + customDtoJson);

            // URL del servicio web RESTful a la que vas a hacer la petición POST
            String url = "https://jsonplaceholder.typicode.com/posts";  // Reemplaza con la URL de tu API

            // Realizar la petición POST y obtener la respuesta
            ResponseEntity<String> responseEntity = apiService.postToApi(
                    url,
                    customDtoJson,
                    customDto.getCustomerUniqueId(), // Deberías reemplazar estos valores por los que correspondan en tu contexto
                    customDto.getRequestId(),
                    customDto.getBusinessLine(),
                    customDto.getSourceApplication(),
                    "PE"
            );

            // Imprimir el cuerpo de la respuesta y el código de estado
            System.out.println("Response from API: " + responseEntity.getBody());
            System.out.println("Response status code: " + responseEntity.getStatusCodeValue());

            int statusCode = responseEntity.getStatusCodeValue();
            if (statusCode == 200 || statusCode == 201) {
                emailEventRepository.updateEmailEventProcessingState(insertedId, "PROCESADO");
                emailEventRepository.updateEmailEventState(insertedId, "COMPLETADO");
            }

        } catch (JsonProcessingException e) {
            throw new JsonProcessingRuntimeException("Error al procesar JSON en Step2Tasklet.", e);
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            throw new ApiCallRuntimeException("Error en la petición HTTP en Step2Tasklet.", e);
        } catch (ResourceAccessException e) {
            throw new ApiCallRuntimeException("No se pudo acceder a la API en Step2Tasklet.", e);
        }

        return RepeatStatus.FINISHED;
    }
}