package com.example.demo.business.impl;

import com.example.demo.converter.StringPositionToCustomDtoConverter;
import com.example.demo.converter.StringToStringPositionConverter;
import com.example.demo.domain.dto.SendMailRequest;
import com.example.demo.domain.entity.MessageEntity;
import com.example.demo.domain.model.StringPosition;
import com.example.demo.exceptions.MessageNotFoundException;
import com.example.demo.exceptions.MessageProcessingRuntimeException;
import com.example.demo.repository.MessageRepository;
import com.example.demo.repository.impl.EmailEventRepositoryImpl;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class EmailEventProcessingStepImpl implements Tasklet {
    @Autowired
    private StringToStringPositionConverter stringConverter;

    @Autowired
    private StringPositionToCustomDtoConverter dtoConverter;
    @Autowired
    private EmailEventRepositoryImpl emailEventRepository;
    @Autowired
    private MessageRepository messageRepository;

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) {
        Long messageId = (Long) chunkContext.getStepContext().getJobParameters().get("messageId");

        if (messageId != null) {
            MessageEntity messageEntity = messageRepository.findById(messageId).orElse(null);
            if (messageEntity != null) {

                String message = messageEntity.getMessage();
                try {
                StringPosition[] positions = stringConverter.convert(message); //aca hay un error
                SendMailRequest customDto = dtoConverter.convert(positions);

                // Aquí, necesitas especificar los valores reales para los otros parámetros también
                int insertedId = emailEventRepository.insertEmailEvent("eventoTipo", "dataQueueEntrada", "dataQueueSalida",
                        "emailDestino", "emailAsunto", "mensaje");
                System.out.println("InsertedID:" + insertedId);
                chunkContext.getStepContext().getStepExecution().getJobExecution()
                        .getExecutionContext().put("insertedId", insertedId);
                chunkContext.getStepContext().getStepExecution().getJobExecution()
                        .getExecutionContext().put("message", message);
                chunkContext.getStepContext().getStepExecution().getJobExecution()
                        .getExecutionContext().put("customDto", customDto);
                System.out.println("mensaje1:" + message);

                } catch (Exception e) {
                    throw new MessageProcessingRuntimeException("Error al procesar el mensaje.", e);
                }
            } else {
                throw new MessageNotFoundException("Mensaje no encontrado para el ID: " + messageId);
            }
        } else {
            throw new MessageNotFoundException("No se proporcionó ningún ID de mensaje.");
        }

        return RepeatStatus.FINISHED;
    }
}

