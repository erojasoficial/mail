package com.example.demo.business;

import org.springframework.batch.core.step.tasklet.Tasklet;

public interface ApiPostAndEmailEventUpdateStep extends Tasklet {}

