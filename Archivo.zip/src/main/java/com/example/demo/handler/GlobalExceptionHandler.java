package com.example.demo.handler;

import com.example.demo.exceptions.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import java.lang.IndexOutOfBoundsException;

@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(IndexOutOfBoundsException.class)
    public ResponseEntity<String> handleIndexOutOfBoundsException(IndexOutOfBoundsException e) {
        return new ResponseEntity<>("Error en los índices de las cadenas: " + e.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(StringConversionException.class)
    public ResponseEntity<String> handleStringConversionException(StringConversionException e) {
        return new ResponseEntity<>("Error en la conversión de la cadena: " + e.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(JsonProcessingRuntimeException.class)
    public ResponseEntity<String> handleJsonProcessingRuntimeException(JsonProcessingRuntimeException e) {
        return new ResponseEntity<>("Error al procesar JSON: " + e.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(ApiCallRuntimeException.class)
    public ResponseEntity<String> handleApiCallRuntimeException(ApiCallRuntimeException e) {
        return new ResponseEntity<>("Error en la llamada a la API: " + e.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<String> handleException(Exception e) {
        return new ResponseEntity<>("Se produjo un error inesperado: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
    @ExceptionHandler(HttpCallRuntimeException.class)
    public ResponseEntity<String> handleHttpCallRuntimeException(HttpCallRuntimeException e) {
        return new ResponseEntity<>("Error en la petición HTTP: " + e.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(NetworkRuntimeException.class)
    public ResponseEntity<String> handleNetworkRuntimeException(NetworkRuntimeException e) {
        return new ResponseEntity<>("No se pudo acceder a la API: " + e.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MessageProcessingRuntimeException.class)
    public ResponseEntity<String> handleMessageProcessingRuntimeException(MessageProcessingRuntimeException e) {
        return new ResponseEntity<>("Error al procesar el mensaje: " + e.getMessage(), HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(MessageNotFoundException.class)
    public ResponseEntity<String> handleMessageNotFoundException(MessageNotFoundException e) {
        return new ResponseEntity<>("Mensaje no encontrado: " + e.getMessage(), HttpStatus.NOT_FOUND);
    }

    @ExceptionHandler(ScheduleServiceException.class)
    public ResponseEntity<String> handleScheduleServiceException(ScheduleServiceException e) {
        return new ResponseEntity<>("Error en ScheduleService: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
